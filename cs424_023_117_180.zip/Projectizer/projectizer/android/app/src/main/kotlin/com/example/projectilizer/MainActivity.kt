package com.example.projectilizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
